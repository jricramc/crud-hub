const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

const parseBody = (body) => {
    if (!body) {
        return
    }

    const type = typeof(body);
    if (type === 'object') {
        return body;
    }

    try {
        // stringified JSON
        return JSON.parse(body)
    } catch (err) {

        // url encoded
        const decodedString = Buffer.from(body, 'base64').toString('utf8');
            
        const inputString = decodedString
        
        // Splitting by '&' to get key-value pairs
        const keyValuePairs = inputString.split('&').map(pair => pair.split('='));
                
        // Convert 2D array to object and decode each URL encoding value 
        const resultObject = keyValuePairs.reduce((obj, [key, value]) => {
            obj[key] = decodeURIComponent(value);
            return obj;
        }, {});

        return resultObject;
    }
};

exports.deleteHandler = async function(event, context) {
    console.log('Received event:', JSON.stringify(event, null, 2));

    // parse the event body
    const bodyObj = parseBody(event.body);

    // Get id and name from the parsed JSON object
    let id = bodyObj.id;
    


    // Parameters for DynamoDB
    let params = {
        TableName : process.env.TABLE_NAME,
        Key: {
            "id": id
        }
    };

    // Call DynamoDB to delete the item from the table
    try {
        await dynamoDB.delete(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({message: "Item deleted"}),
        };
    } catch (error) {
        console.log('Error deleting item from table:', error);
        return {
            statusCode: 500,
            body: JSON.stringify(error),
        };
    }
};
