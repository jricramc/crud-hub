const AWS = require('aws-sdk');
const ses = new AWS.SES();

exports.handler = async (event) => {
    try {
        const res = await sendEmail(event.subject, event.content, event.email);
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Email sent successfully!', res })
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Failed to send email.' })
        };
    }
};

function sendEmail(subject, content, email) {
    console.log('Sending email with subject:', subject);
    const params = {
        Destination: {
            ToAddresses: [email]
        },
        Message: {
            Body: {
                Html: { Data: content, Charset: 'UTF-8' } 
            },
            Subject: { Data: subject }
        },
        Source: 'webhubhq@gmail.com'
    };

    return ses.sendEmail(params).promise();
}

const sendRawEmail = (subject, content, email) => {
    const sourceEmail = 'webhubhq@gmail.com';
    // Construct the raw email message
    const rawEmail = `
        From: ${sourceEmail}
        To: ${email}
        Subject: ${subject}
        Content-Type: text/html; charset=utf-8

        ${content}
    `;

    // Email parameters
    const params = {
        RawMessage: {
            Data: rawEmail,
        },
        Destinations: [email],
        Source: sourceEmail,
    };
    
    return ses.sendRawEmail(params).promise();
};
