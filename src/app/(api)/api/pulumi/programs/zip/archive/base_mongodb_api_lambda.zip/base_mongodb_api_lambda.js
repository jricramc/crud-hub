/*
  MongoDB Atlas
  Data Source: ServerlessInstance0, API Key: 75pQZG2c9zFlpG0g6XCrQCT2BH7fvv1KDYpDJAPUQysxI4Etjrpqvff9n7thEsXP
*/


// import { MongoClient } from 'mongodb';

// // Get the URI for the cluster then set AWS_ACCESS_KEY_ID as the username in the
// // URI and AWS_SECRET_ACCESS_KEY as the password, then set the appropriate auth
// // options. Note that MongoClient now auto-connects so no need to store the connect()
// // promise anywhere and reference it.
// const client = new MongoClient(process.env.MONGODB_URI, {
//   auth: {
//     username: process.env.AWS_ACCESS_KEY_ID,
//     password: process.env.AWS_SECRET_ACCESS_KEY
//   },
//   authSource: '$external',
//   authMechanism: 'MONGODB-AWS'
// });


const executeRequest = async ({ mongo, request, global_variables }) => {
    const { method, args, variable, chain } = request?.request || {};
    
    if (!request || !method) {
      return [{
        code: "format_issue",
        message: "Undefined or improperly formatted request in chain.",
        error_loc: request.loc,
        error_chain: request.chain
      }];
    }
    
    const documentation_url = {
      base: "https://mongodb.github.io/node-mongodb-native",
      version: "6.3",
    }
    
    // documentation url structure: `${documentation_url.base}/${documentation_url.version}/${mongodb_classes[request_class]}.html#${methods[method]}`
    // check what type of method it is, a function or key for example: .connect() vs ['asyncIterator']()
    // technically all .methodName() can be formatted as ['methodName']()
    
    let m = null;
    let mHashTag = null;
    
    // type 1 method .methodName() regex
    const type_1_method_regex = /^(\.)(\w+)(\(\))/;
    const match_type_1 = method.match(type_1_method_regex)
    if (match_type_1) {
      const [, , methodName] = match_type_1;
      m = methodName;
      mHashTag = methodName;
    } else {
      // type 2 method .methodName() regex
      const type_2_method_regex = /^(\[[\"\'])(.*)([\"\']\])(\(\))/;
      const match_type_2 = method.match(type_2_method_regex)
      if (match_type_2) {
        const [, , methodName] = match_type_2;
        m = methodName;
        mHashTag = `_${methodName}_`;
      }
    }
    
    if (!m) {
      return [{
        code: "format_issue",
        message: `Method name not formatted correctly: ${method}. Must be of the form: .connect() or ['connect']() as an example.`,
        error: { request },
        mongo_variable: mongo,
      }];
    }
    
    
    // Next check if the method is valid to do on the mongo variable
    if (!mongo[m]) {
      return [{
        code: "method_not_found",
        message: `The mongodb variable doesn't not have a method with the name ${m}.`,
        error: { request },
        mongo_variable: mongo,
      }];
    }
    
    // next regardless we will try running the function with the given args
    let res = null;
    // make a copy
    let request_chain = request.chain.slice();
    try {
      // always await even if the function doesn't return a promise
      res = await mongo[method](...args);
      request_chain.push(`.${method}(${Object.stringify(args)})`);
    } catch (err) {
      return [{
        code: "execution_error",
        message: "Couldn't execute last command in chain. Check error and review MongoDB documentation.",
        error: {
          request,
          catch: err,
          // still need to have a reliable way of parsing mongo variable class name
          // documentation_url: `${documentation_url.base}/${documentation_url.version}/${}.html#${mHashTag}`
        },
        mongo_variable: mongo,
      }];
    }
    
    if (res) {
      
      // check if we should save the variable name
      if (variable?.name) {
        global_variables[variable.name] = { value: res, return: variable?.return };
      }
      
      if (chain.length === 0) {
        return [{
          code: "chain_complete",
          message: "This chain ran successfully!",
          success: { request, value: res },
        }];
      }
      
      // lastly check if there is a chain of request that needs to be executed
      const request_statuses = await Promise.all((chain || []).map((request, i) => executeRequest({
        mongo: res,
        request: { request, loc: request.loc.concat([i]), chain: request_chain },
        global_variables
      })));
      
      // return request_statuses (compress 2D array to 1D)
      return request_statuses.flat();
    }
    
    
  };
  
  export const handler = async (event) => {
    // TODO implement
    
    const codes = {
      "format_issue": "improperly formatted json",
    };
    
    const { MongoClient: MC } = event;
    
    const variables = {};
    
    let response_statuses = [];
    
    
    if (MC) {
      let request = MC;
      
      const client = null;
      
      response_statuses = await executeRequest({
        global_variables: variables,
        mongo: client,
        request: { request, loc: ['MongoClient'], chain: ['MongoClient'] },
      });
    } else {
      response_statuses = [{
        code: "format_issue",
        message: "request must start with MongoClient",
        error: { request: MC },
      }];
    }
    
    
    const response = {
      statusCode: 200,
      body: JSON.stringify({ response: {
        status: response_statuses,
        variables,
      }}),
    };
    
    return response;
    
  };
  